#ifndef PLAYERSHIPMODEL_H
#define PLAYERSHIPMODEL_H

#include "Model.h"

namespace Asteroids {

	class PlayerShipModel : public Model {

	public :
	
		PlayerShipModel();
		~PlayerShipModel();

	};

}

#endif