#ifndef ENEMYSHIPMODEL_H
#define ENEMYSHIPMODEL_H

#include "Model.h"

namespace Asteroids {

	class EnemyShipModel : public Model {

	public :
	
		EnemyShipModel();
		~EnemyShipModel();

	};

}

#endif