#ifndef LASERMODEL_H
#define LASERMODEL_H

namespace Asteroids {

	class LaserModel : public Model {

	};

}

#endif